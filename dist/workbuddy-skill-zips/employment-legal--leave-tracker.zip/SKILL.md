---
name: "劳动用工法务-休假/假期管理"
description: >
  用于中国大陆劳动用工法务场景下的休假/假期管理。输出默认简体中文；正式依赖前需法务负责人或执业律师核验。
  Check open leaves for deadline alerts and required decisions. Surfaces only the leaves
  that require an action and explains why — not a status board. Use weekly, or whenever
  the attorney needs to know which leaves have upcoming designation, certification, or
  exhaustion deadlines. WorkBuddy
  中国语境适配：默认中国大陆法域，用于劳动用工法务场景下的休假/假期管理。中文触发词包括：中国法、中国合规、劳动用工法务、休假/假期管理、法务审查、律师审阅。输出为草稿或内部分析，需执业律师/法务负责人核验后方可依赖。
---

## WorkBuddy 中国语境适配（优先）

本 skill 已转换为 WorkBuddy 中国语境版本。当前模块：**劳动用工法务**；当前技能：**休假/假期管理**。

在执行下方原流程前，先读取并遵守：

- `references/china-context.md`（本模块中国语境规则）
- `references/china-legal-context.md`（全局中国法律语境总则）

除非用户明确指定其他法域，默认适用**中国大陆**。下方原文中的美国州法、Delaware、ABA、CourtListener、Westlaw、DMCA、NPRM、deposition、subpoena、attorney work product 等内容均视为原模板遗留项；遇到冲突时，以中国法、监管机关、司法/仲裁程序、团队 playbook 和本适配段为准。

输出默认使用简体中文。法律、法规、司法解释、监管规则、国家标准、案例或截止日不能确认现行有效时，标注 `[需核验]`，并给出应核验的官方来源或授权数据库。对外发送、正式提交、董事会/股东会文件、劳动解除、数据出境、监管回复、诉讼/仲裁文件等后果性动作，必须经过执业律师或法务负责人确认。

---


# /leave-tracker

Checks all open leaves with hard legal deadlines and surfaces only the ones
requiring a decision or action. Not a status board — tells you what you need
to do and why.

## Instructions

1. Load the `leave-tracker` agent and run the full workflow.

2. If no HRIS is connected and no `~/.workbuddy/skills/config/workbuddy-cn-legal/employment-legal/leave-register.yaml` exists, prompt
   the attorney to upload a leave spreadsheet or use
   `/employment-legal:log-leave` to add entries.

3. Alerts only for leaves requiring action. Clean leaves summarized one line each.

## Examples

```
/employment-legal:leave-tracker
```

Run this weekly — set a Monday-morning reminder to invoke
`/employment-legal:leave-tracker`. Automated scheduling requires a separate
integration (calendar reminder, cron job, etc.); WorkBuddy agents do not
self-schedule.
