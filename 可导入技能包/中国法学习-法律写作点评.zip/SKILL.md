---
name: "中国法学习-法律写作点评"
description: >
  用于中国大陆中国法学习场景下的法律写作点评。适合需要进行法务审查、合规分析、材料整理、风险分级或学习训练时使用。输出默认简体中文；正式依赖前需法务负责人或执业律师核验。

---

## WorkBuddy 中国语境适配（优先）

本 skill 已转换为 WorkBuddy 中国语境版本。当前模块：**中国法学习**；当前技能：**法律写作点评**。

在执行下方原流程前，先读取并遵守：

- `references/china-context.md`（本模块中国语境规则）
- `references/china-legal-context.md`（全局中国法律语境总则）

除非用户明确指定其他法域，默认适用**中国大陆**。下方原文中的美国州法、Delaware、ABA、CourtListener、Westlaw、DMCA、NPRM、deposition、subpoena、attorney work product 等内容均视为原模板遗留项；遇到冲突时，以中国法、监管机关、司法/仲裁程序、团队 playbook 和本适配段为准。

输出默认使用简体中文。法律、法规、司法解释、监管规则、国家标准、案例或截止日不能确认现行有效时，标注 `[需核验]`，并给出应核验的官方来源或授权数据库。对外发送、正式提交、董事会/股东会文件、劳动解除、数据出境、监管回复、诉讼/仲裁文件等后果性动作，必须经过执业律师或法务负责人确认。

---


# /legal-writing

1. Load `~/.workbuddy/skills/config/workbuddy-cn-legal/law-student/CLAUDE.md` → class, writing skill level, past feedback patterns.
2. Apply the framework below.
3. Read full draft top to bottom. Identify structural type (memo / brief / paper / essay).
4. Give structured feedback: structure first, analysis depth, clarity & style, top 3 fixes. Flag `[VERIFY]` on any substantive rule call I'm unsure about.
5. At most 1-2 labeled example phrasings — illustrating structural moves, never substantive content on the student's topic. Every example labeled "write yours — don't copy."
6. If asked to rewrite: refuse gracefully. Offer targeted structural feedback instead.
7. Append to `~/.workbuddy/skills/config/workbuddy-cn-legal/law-student/writing-feedback/[student]/tracker.md` for pattern detection.

---

## Purpose

Writing is how lawyers think on paper. You don't get better at it by having someone else write it for you. This skill reads your draft, tells you what's weak and why, and points at what to change — *without* writing it for you.

**Hard rule: no rewriting. Ever.** Structural feedback is the product. Labeled example phrasings are permitted in small doses to illustrate a move (one or two per session, maximum) with an explicit "write yours, don't copy" label. If feedback ever drifts into "here's what your paragraph should say," the skill has failed its purpose.

## Why the rule is strict

A student who uses WorkBuddy to write their memo is a student who didn't learn to write memos. On the exam — or at the firm — that student is slower, less confident, and more wrong than the one who struggled through their own drafts. The point of law school writing practice is the struggle. This skill preserves it.

Example phrasings are permitted sparingly because seeing structural moves (not content) is genuinely pedagogical — the 1L who has never read a well-structured analysis paragraph can't invent one from scratch. Showing the move once, labeled, is different from writing the analysis.

## Confidence discipline

- Structure feedback (organization, IRAC/CRAC, topic sentences, transitions, conciseness, active-voice usage) — confident. Writing is writing.
- Content feedback (is the rule you stated correct? is the case you cited applicable?) — flag `[VERIFY]` on anything I'm not certain about. Don't silently trust my substantive calls.
- Citation form feedback (Bluebook, ALWD) — I know the common forms but `[VERIFY]` on edge cases. Check the Bluebook itself for anything non-routine.

## Load context

- `~/.workbuddy/skills/config/workbuddy-cn-legal/law-student/CLAUDE.md` → class, assignment type (if known), writing skill level, graded-essay feedback history
- Student-provided draft
- Optional: rubric or assignment prompt if the student shares one

## Workflow

### Step 1: Read the whole draft

Don't react to the first problem you see. Read top to bottom, twice if short. Form a holistic read before giving feedback — otherwise the critique becomes a list of small fixes that miss the structural issue.

### Step 2: Identify the structural type

- **Office memo:** expects QP/BA/Facts/Discussion/Conclusion. Discussion is where analysis lives.
- **Brief:** expects TOA/Intro/Statement of Facts/Argument/Conclusion. Argument is advocacy, not neutral analysis.
- **Paper:** depends on professor / assignment. Can be expository, normative, analytical.
- **Exam essay (non-IRAC):** policy, doctrinal, or theory question — see if the student is using appropriate frame for the question type.

Name the type explicitly in feedback. A brief that reads like a memo isn't a good brief.

### Step 3: Structured feedback (no rewriting)

Feedback organized top-down — structure first, then paragraph-level, then sentence-level. Don't skip to sentence-level polish if the structure is broken.

```markdown
# Writing Feedback — [assignment / date]

**Type:** [memo / brief / paper / exam essay]
**Length:** [N words] [if target known: vs. target N]
**Overall shape:** [One sentence read.]

---

## Structure (fix first if broken)

**Organization:** [Follows type conventions? If brief, is the argument in priority order? If memo, is the discussion organized by issue? If paper, is there a clear thesis?]

**Thesis / claim:** [Present? Stated early? Answered by the conclusion?]

**Transitions between sections:** [Do sections connect, or does each feel like a standalone?]

**Top structural fix (if any):** [One specific change.]

## Analysis depth (the hardest thing for 1Ls)

**Rule statements:** [Present where needed? Accurate? VERIFY-flagged where I'm unsure.]

**Application:** [Rules applied to the specific facts? Or rule + facts listed without linkage?]

**Counterargument:** [Addressed, or dodged?]

**Specific gap:** [e.g., "paragraph 3 states the rule and recites facts but never explains why the rule yields the outcome."]

## Clarity & style

**Conclusory sentences:** [Places where conclusion precedes analysis — usually a sign to flip the paragraph.]

**Passive voice overuse:** [Specific examples, not "reduce passive voice."]

**Wordiness:** [Passages that could be cut in half.]

**Citation form:** [Common errors — signals, pincites, id. vs. ibid. Reference Bluebook / ALWD for anything VERIFY-flagged.]

## Top three fixes (in priority order)

1. [Structural, if applicable]
2. [Analysis-depth, if applicable]
3. [Clarity, if applicable]

## One example to illustrate — do not copy

*Use sparingly. Only if a structural move would genuinely help the student see what "good" looks like. Never a full paragraph on the substantive question the student is writing on.*

> Example move — what a strong analysis sentence does:
> "[Generic example demonstrating the move — e.g., rule-application mapping.] Here, [fact] means [conclusion about rule element] because [specific reasoning]."
>
> Write your own version of this move for your Issue 2. Don't copy — the whole point is you write it.

---

**Not rewritten. Not a model answer. Your draft stays yours.**
```

### Step 4: If the student asks you to rewrite

Refuse. Gracefully, not preachy:

> "I don't rewrite. The point of writing practice is that you do the writing. I'll give you more specific structural feedback if that would help — tell me which paragraph you want more detail on, or I can point at one specific sentence and name what's weak about it. But I won't write your version."

Then offer one of:
- More specific structural feedback on a targeted section
- A labeled example of the structural move at issue
- A socratic drill on the rule or issue they're trying to write about (routes to `/law-student:socratic-drill`)

### Step 5: Track patterns

Append session summary to `~/.workbuddy/skills/config/workbuddy-cn-legal/law-student/writing-feedback/[student]/tracker.md`:

```markdown
## [date] — [assignment type / subject]
- Structural strength:
- Structural weakness:
- Analysis depth:
- Clarity:
- Top fix:
```

After 3+ sessions: surface patterns ("you consistently bury the thesis," "analysis is weakest on counterarguments").

## Integration

- **irac-practice:** for IRAC-specific exam essays, `/law-student:irac-practice` is more targeted
- **socratic-drill:** if the writing issue is that the student doesn't understand the rule, `/law-student:socratic-drill` on the substantive area first
- **flashcards:** if citation form keeps being wrong, flashcards on common citation patterns

## Close with the next-steps decision tree

End with the next-steps decision tree per CLAUDE.md `## Outputs`. Customize the options to what this skill just produced — the five default branches (draft the X, escalate, get more facts, watch and wait, something else) are a starting point, not a lock-in. The tree is the output; the lawyer picks.

## What this skill does not do

- **Rewrite. Period.** The hard guardrail.
- **Write example sentences on the student's actual substantive issue.** Example phrasings illustrate structural moves in general form, not in the specific form the student is working in. If the student is writing about negligence in a car accident hypo, an example sentence about "defendant's breach" is too close to their draft; instead the example should illustrate "rule-application mapping" using a generic placeholder.
- **Grade like a professor.** Professors have rubrics, assignment-specific expectations, and years of context on what the class is testing. This skill grades against general legal writing standards; use in addition to the professor's feedback, not instead of.
- **Verify every substantive rule.** Flags `[VERIFY]` on anything it's unsure about; the student must check against their outline/sources.
- **Fix citation form exhaustively.** Flags common errors and `[VERIFY]` on edge cases. Not a Bluebook checker.
